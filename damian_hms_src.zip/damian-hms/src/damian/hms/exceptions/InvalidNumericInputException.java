package damian.hms.exceptions;

public class InvalidNumericInputException extends RuntimeException {
	public InvalidNumericInputException(String message, Throwable cause) {
		super(message, cause);
		
	}
}

package damian.hms.exceptions;

public class InvalidEmptyInputException extends Exception {
	public InvalidEmptyInputException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}

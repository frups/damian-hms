package damian.hms.enums;

public enum PROFESSIONS {
	DOCTOR,
	NURSE,
	OTHER
}

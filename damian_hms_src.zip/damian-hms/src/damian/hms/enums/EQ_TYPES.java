package damian.hms.enums;

public enum EQ_TYPES {
	MEDICATION,
	FURNITURES,
	APPARATUS
}

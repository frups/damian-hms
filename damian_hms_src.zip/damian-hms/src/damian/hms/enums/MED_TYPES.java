package damian.hms.enums;

public enum MED_TYPES {
	LIQUID,
	TABLET,
	INJECTION
}

package damian.hms.enums;

public enum DISEASES {
	CANCER,
	FRACTURE,
	POISONING,
	COVID,
	GUNSHOT,
	STROKE,
	PSYCHO
}


package damian.hms.enums;

public enum SERVICE_TYPES {
	SURGERY,
	THREATMENT,
	TEST,
	CONSULTATION
}

package damian.hms.enums;

public enum ROOM_TYPES {
	OPERATING_THEATER,
	TREATMENT_ROOM,
	CABINET,
	PHARMACY
}

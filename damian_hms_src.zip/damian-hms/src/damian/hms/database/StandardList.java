package damian.hms.database;

import damian.hms.application.HospitalStaff;

public abstract class StandardList {
	int counter = 0;


}
